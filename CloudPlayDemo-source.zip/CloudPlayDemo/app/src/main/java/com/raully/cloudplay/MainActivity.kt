package com.raully.cloudplay

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 13, 18)
    private val panel = Color.rgb(18, 25, 33)
    private val muted = Color.rgb(150, 164, 178)
    private val lime = Color.rgb(156, 255, 87)
    private lateinit var games: LinearLayout
    private lateinit var pcTab: TextView
    private lateinit var consoleTab: TextView
    private var selected = "PC"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        render()
    }

    private fun render() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(18), dp(20), dp(22))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        scroll.addView(page)

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        brandRow.addView(label("CLOUDPLAY", 18f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        brandRow.addView(label("APP DE DEMONSTRAÇÃO", 10f, lime, true).apply {
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(Color.rgb(31, 48, 34), 20)
        })
        page.addView(brandRow)
        page.addView(space(26))

        page.addView(label("Jogue pela nuvem.", 30f, Color.WHITE, true))
        page.addView(label("Uma prévia do aplicativo de streaming de jogos.", 14f, muted, false).apply {
            setPadding(0, dp(8), 0, 0)
        })
        page.addView(space(20))

        val warning = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(Color.rgb(41, 34, 19), 18)
        }
        warning.addView(label("DEMONSTRAÇÃO — SEM SERVIDOR", 12f, Color.rgb(255, 205, 94), true))
        warning.addView(label("Este APK ainda não transmite nem inicia jogos. Não há servidores conectados.", 13f, Color.rgb(231, 218, 187), false).apply {
            setPadding(0, dp(8), 0, 0)
        })
        page.addView(warning)
        page.addView(space(18))

        val status = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(panel, 16)
        }
        status.addView(dot(), LinearLayout.LayoutParams(dp(10), dp(10)))
        status.addView(label("  Serviço de streaming", 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        status.addView(label("NÃO CONECTADO", 10f, muted, true))
        page.addView(status)
        page.addView(space(24))

        page.addView(label("Biblioteca de demonstração", 19f, Color.WHITE, true))
        page.addView(label("Selecione uma categoria", 13f, muted, false).apply {
            setPadding(0, dp(5), 0, dp(14))
        })
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pcTab = tab("PC")
        consoleTab = tab("CONSOLE")
        tabs.addView(pcTab, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(7) })
        tabs.addView(consoleTab, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(7) })
        page.addView(tabs)
        page.addView(space(12))
        games = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(games)

        val connect = Button(this).apply {
            text = "TESTAR CONEXÃO"
            setTextColor(bg)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setBackgroundColor(lime)
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Demonstração: ainda não há servidor para conectar.", Toast.LENGTH_LONG).show()
            }
        }
        page.addView(space(18))
        page.addView(connect, LinearLayout.LayoutParams(-1, dp(52)))
        page.addView(label("Grátis • sem moedas • sem fila — objetivos do projeto, ainda não ativos.", 11f, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        setContentView(scroll)
        updateCategory()
    }

    private fun updateCategory() {
        pcTab.background = rounded(if (selected == "PC") Color.rgb(47, 68, 42) else panel, 14)
        pcTab.setTextColor(if (selected == "PC") lime else muted)
        consoleTab.background = rounded(if (selected == "CONSOLE") Color.rgb(47, 68, 42) else panel, 14)
        consoleTab.setTextColor(if (selected == "CONSOLE") lime else muted)
        games.removeAllViews()
        val list = if (selected == "PC") listOf("Aventura para PC", "Corrida para PC") else listOf("Aventura de console", "Ação de console")
        list.forEachIndexed { i, name ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = rounded(panel, 16)
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(name, 15f, Color.WHITE, true))
            info.addView(label("Título fictício • catálogo de exemplo", 11f, muted, false).apply { setPadding(0, dp(5), 0, 0) })
            card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val unavailable = label("EM BREVE", 10f, muted, true).apply {
                setPadding(dp(9), dp(7), dp(9), dp(7))
                background = rounded(Color.rgb(29, 38, 47), 20)
            }
            card.addView(unavailable)
            games.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
            card.setOnClickListener {
                Toast.makeText(this, "Ainda não disponível: falta conectar os servidores de jogos.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun tab(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setOnClickListener {
            selected = text
            updateCategory()
        }
    }

    private fun dot(): View = View(this).apply { background = rounded(lime, 20) }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }
}
