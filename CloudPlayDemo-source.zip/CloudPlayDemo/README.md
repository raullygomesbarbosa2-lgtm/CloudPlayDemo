# CloudPlay Demo (Android)

A clearly labeled Android UI demo for the proposed cloud-gaming product. It does **not** stream, launch, or include games; no streaming servers or game catalog are connected. The game cards and connection button are illustrative only.

Product goals recorded for a future service: free app, no coins, no queue, PC and console streaming. These require streaming infrastructure, authorized game access, and sufficient capacity and are not implemented in this demo.

Build: `gradle :app:assembleDebug` with JDK 17 and Android SDK 35.
